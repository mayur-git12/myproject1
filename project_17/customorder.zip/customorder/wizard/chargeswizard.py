from odoo import models, fields, api

class SaleOrderWizard(models.TransientModel):
    _name = 'sale.order.wizard'
    _description = 'Sale Order Extra Charges Wizard'

    extra_charges = fields.Float(string="Extra Charges")
