{
    'name': 'myorder',
    'version': '1.0',
    'depends': ['sale'],
    'data': [
        'views/wizard_view.xml'
        'views/charges.xml',
        'views/sale_line.xml',
    ],
    'installable': True,
    'application': True,
}