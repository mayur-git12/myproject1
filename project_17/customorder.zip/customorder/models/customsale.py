from odoo import models, fields, api

class Customsales(models.Model):
    _inherit = 'sale.order'

    consumable_lines = fields.One2many('sale.order.line', 'order_id', domain=[('product_id.type', '=', 'consu')])
    service_lines = fields.One2many('sale.order.line', 'order_id', domain=[('product_id.type', '=', 'service')])


    def action_open_charges_wizard(self):
        self.ensure_one()
        return {
            'name': ("Extra Charges"),
            'type': 'ir.actions.act_window',
            'res_model': 'sale.order.discount',
            'view_mode': 'form',
            'target': 'new',
        }

class Customorderline(models.Model):
    _inherit = 'sale.order.line'

    charges = fields.Float("extra charges")